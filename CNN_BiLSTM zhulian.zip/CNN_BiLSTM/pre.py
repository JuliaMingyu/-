import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams['font.sans-serif'] = 'SimHei' # 设置中文显示
plt.rcParams['axes.unicode_minus'] = False

df = pd.read_excel('data.xlsx')
df['Date'] = pd.to_datetime(df['Year'].astype(str) + '-' + df['Day'].astype(str), format='%Y-%j')
df.set_index('Date', inplace=True)
df.drop(['Year', 'Day'], axis=1, inplace=True)

# 生成时间范围
start_date = pd.Timestamp('1990-01-01')
end_date = pd.Timestamp('2023-03-01')
date_range = pd.date_range(start=start_date, end=end_date, freq='D')

# 检查时间范围中是否包含DataFrame中的所有日期
missing_dates = date_range[~date_range.isin(df.index)]
print("Missing Dates:")
print(missing_dates)
print(len(df.columns))
# 定义划分比例
train_ratio = 0.7
val_ratio = 0.1
test_ratio = 0.2

# 计算划分的索引
train_split = int(train_ratio * len(df))
val_split = int((train_ratio + val_ratio) * len(df))

# 划分数据集
train_set = df.iloc[:train_split]
val_set = df.iloc[train_split:val_split]
test_set = df.iloc[val_split:]

plt.figure(figsize=(15, 10))
plt.subplot(3,1,1)
plt.plot(train_set, color='g',  alpha=0.3)
plt.title('train Temperature时序图')

plt.subplot(3,1,2)
plt.plot(val_set, color='b',  alpha=0.3)
plt.title('val Temperature时序图')

plt.subplot(3,1,3)
plt.plot(test_set, color='r',  alpha=0.3)
plt.title('test Temperature时序图')
plt.xticks(rotation=45)
plt.show()

#将一列数据变化到某个固定区间(范围)中，通常，这个区间是[0, 1] 或者（-1,1）之间的小数。主要是为了数据处理方便提出来的，把数据映射到0～1范围之内处理，更加便捷快速。
from sklearn.preprocessing import MinMaxScaler


def normalize_dataframe(train_set, val_set, test_set):
    scaler = MinMaxScaler()
    scaler.fit(train_set)  # 在训练集上拟合归一化模型

    train = pd.DataFrame(scaler.transform(train_set), columns=train_set.columns, index=train_set.index)
    val = pd.DataFrame(scaler.transform(val_set), columns=val_set.columns, index=val_set.index)
    test = pd.DataFrame(scaler.transform(test_set), columns=test_set.columns, index=test_set.index)
    return train, val, test


train, val, test = normalize_dataframe(train_set, val_set, test_set)

plt.figure(figsize=(15, 10))
plt.subplot(3, 1, 1)
plt.plot(train, color='g', alpha=0.3)
plt.title('train Temperature归一化时序图')

plt.subplot(3, 1, 2)
plt.plot(val, color='b', alpha=0.3)
plt.title('val Temperature归一化时序图')

plt.subplot(3, 1, 3)
plt.plot(test, color='r', alpha=0.3)
plt.title('test Temperature归一化时序图')
plt.xticks(rotation=45)
plt.show()

def prepare_data(data, win_size):
    X = []
    y = []

    for i in range(len(data) - win_size):
        temp_x = data[i:i + win_size]
        temp_y = data[i + win_size]
        X.append(temp_x)
        y.append(temp_y)

    X = np.asarray(X)
    y = np.asarray(y)
    X = np.expand_dims(X, axis=-1)
    return X, y

win_size = 30

# 训练集
X_train, y_train= prepare_data(train['Temperature'].values, win_size)

# 验证集
X_val, y_val= prepare_data(val['Temperature'].values, win_size)

# 测试集
X_test, y_test = prepare_data(test['Temperature'].values, win_size)

print("训练集形状:", X_train.shape, y_train.shape)
print("验证集形状:", X_val.shape, y_val.shape)
print("测试集形状:", X_test.shape, y_test.shape)

def get_prepared_data():
    return X_train, y_train, X_val, y_val, X_test, y_test

def get_datasets():
    return train_set, val_set, test_set
