from tensorflow.keras.layers import Conv1D, MaxPooling1D, Reshape, Flatten
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import pre
import tensorflow as tf
from tensorflow.keras import layers, models, Input
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Bidirectional, Dense

X_train, y_train, X_val, y_val, X_test, y_test = pre.get_prepared_data()
train_set, val_set, test_set = pre.get_datasets()

# 计算训练集的最大值和最小值用于反归一化
df_max = train_set.max().max()
df_min = train_set.min().min()

model_cnn_bilstm = Sequential()
model_cnn_bilstm.add(Bidirectional(LSTM(128, activation='relu'), input_shape=(X_train.shape[1], X_train.shape[2])))
# 添加Reshape层将LSTM的输出转换为3维
model_cnn_bilstm.add(Reshape((256, 1)))
model_cnn_bilstm.add(Conv1D(filters=64, kernel_size=7, activation='relu'))
model_cnn_bilstm.add(MaxPooling1D(pool_size=2))
model_cnn_bilstm.add(Flatten()) # 将池化后的输出展平成一维向量
model_cnn_bilstm.add(Dense(32, activation='relu'))
model_cnn_bilstm.add(Dense(16, activation='relu'))
model_cnn_bilstm.add(Dense(1))

model_cnn_bilstm.compile(optimizer='adam', loss='mse')
history = model_cnn_bilstm.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_val, y_val))

plt.figure()
plt.plot(history.history['loss'], c='b', label = 'loss')
plt.plot(history.history['val_loss'], c='g', label = 'val_loss')
plt.legend()
plt.show()

from sklearn import metrics
model_cnn_bilstm.summary()
y_pred = model_cnn_bilstm.predict(X_test)
mse = metrics.mean_squared_error(y_test, np.array([i for arr in y_pred for i in arr]))
rmse = np.sqrt(mse)
mae = metrics.mean_absolute_error(y_test, np.array([i for arr in y_pred for i in arr]))
from sklearn.metrics import r2_score
r2 = r2_score(y_test, np.array([i for arr in y_pred for i in arr]))
print("均方误差 (MSE):", mse)
print("均方根误差 (RMSE):", rmse)
print("平均绝对误差 (MAE):", mae)
print("拟合优度:", r2)

last_output = model_cnn_bilstm.predict(X_test)[-1]
steps = 10
predicted = []
for i in range(steps):
    input_data = np.append(X_test[-1][1:], last_output).reshape(1, X_test.shape[1], X_test.shape[2])
    next_output = model_cnn_bilstm.predict(input_data)
    predicted.append(next_output[0][0])
    last_output = next_output[0]

series_2 = np.array(predicted) * (df_max - df_min) + df_min

plt.figure(figsize=(15, 4), dpi=300)
plt.subplot(3, 1, 1)
plt.plot(train_set, color='c', label='训练集')
plt.plot(val_set, color='r', label='验证集')
plt.plot(test_set, color='b', label='测试集')
plt.plot(pd.date_range(start='2016-08-12', end='2023-03-01', freq='D')
         , y_pred * (df_max - df_min) + df_min, color='y', label='测试集预测')

plt.plot(pd.date_range(start='2023-03-02', end='2023-03-11', freq='D')
         , series_2, color='magenta', linestyle='-.', label='未来预测')
plt.legend()
plt.subplot(3, 1, 2)
plt.plot(test_set, color='b', label='测试集')
plt.plot(pd.date_range(start='2016-08-12', end='2023-03-01', freq='D')
         , y_pred * (df_max - df_min) + df_min, color='y', label='测试集预测')

plt.plot(pd.date_range(start='2023-03-02', end='2023-03-11', freq='D')
         , series_2, color='magenta', linestyle='-.', label='未来预测')
plt.legend()

plt.subplot(3, 1, 3)
plt.plot(test_set, color='b', label='测试集')
plt.plot(pd.date_range(start='2016-08-12', end='2023-03-01', freq='D')
         , y_pred * (df_max - df_min) + df_min, color='y', label='测试集预测')

plt.plot(pd.date_range(start='2023-03-02', end='2023-03-11', freq='D')
         , series_2, color='magenta', linestyle='-.', label='未来预测')
# 设置x轴范围为2022年到未来预测的结束日期
plt.xlim(pd.Timestamp('2022-01-01'), pd.Timestamp('2023-03-11'))
plt.legend()
plt.show()